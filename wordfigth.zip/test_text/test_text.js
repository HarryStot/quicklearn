var rep_vrai = 0; // compteur réponse vrai
var rep_faux = 0; // compteur réponse fausse
var pv = 100; // nombre point de vie
var v = 0; // variable mot question
var r = 0; // variable mot réponse
var x = 0; // savoir si vrai(1) ou faux (2)

let voc_que = [ 'hello', 'thank you','mouse','keyboard']; // voc question
let voc_rep = ['bonjour', 'merci','mouse','keyboard']; // voc réponse


var bv1 = {  // barre de vie jaune
  x: 10, 
  y: 10, 
  l: 200, 
  L: 30
}

var bv2 = { // barre de vie rouge
  x: 10, 
  y: 10, 
  l: 200, 
  L: 30
}


function setup() {
  createCanvas(window.innerWidth, window.innerHeight); // création d'un canvas en fonction de la taille de l'écran
  textSize(40); // on défini la taille de la police 
  noStroke(); 
  fill(255, 255, 0); // on créé la barre de vie 
  rect(bv1.x, bv1.y, bv1.l, bv1.L);
  fill(0);
  text('PV : '+pv,210 ,40); // on affiche les infos
  text('Réponse juste :'+rep_vrai, width-(width-10),height-(height-75));
  text('Réponse fausse :'+ rep_faux, width-(width-10),height-(height-120));
  text('Que veut dire : '+ voc_que[v],(width/2) - 250 ,(height/2)-80);
  
}


function getValue() {
  clear(); // on supprime tout de l'écran
  var input = document.getElementById("reponse").value; // Sélectionner l'élément rentrer dans la barre de saisie html et récupérer sa valeur
  noStroke();
  fill(255, 0, 0); // recréation de la barre de vie en fonction des variables
  rect(bv1.x, bv1.y, bv1.l, bv1.L);
  fill(255, 0, 0);
  rect(bv2.x, bv2.y, bv2.l, bv2.L);
  fill(0);
  text('Que veut dire : '+voc_que[v+1],(width/2) - 250 ,(height/2)-80);
  if ( input == voc_rep[r]) {  // on regarde si le mot taper correspond au mot de vocabulaire
    x = 1;
    rep_vrai = rep_vrai + 1; // si oui on incrémante 1 au nombre de bonne réponse
    fill(0);
    text('PV : '+pv,210 ,40); // on affiche son nombre de pv
    textSize(70);
    text('BRAVO', (width/2) - 250,height-(height-220)); // on le félicite
    textSize(40);
    
    reponse(); // on affiche le nombre de réponse
    
  } else { //si il a faut    
    x = 2;
    pv = pv - 10; //on retire des pv
    bv2.l = bv2.l - 10; // on retire 10 pixel de la barre de vie
    rep_faux = rep_faux + 1; // on incrémente 1 au nombre de mauvaise réponse
    fill(0);
    text('PV : '+pv,210 ,40); 
    textSize(70);
    text('PERDU', (width/2) - 250,height-(height-220));    
    textSize(40);    
    reponse();  
  }
  if (bv2.l > 0) { // il sert à retirer des pixel tant que la barre n'atteint pas 0 
    fill(255, 255, 0);
    rect(bv2.x, bv2.y, bv2.l, bv2.L);
  }
  if (bv2.l == 0) { // une fois la barre à 0 on lui indique qu'il n'a plus de vie
    fill(0);
    text('Plus de vie', (width/2) - 200,height-(height-220));
    document.location.href="test.html"; //une fois le jeu fini redirection vers une page de fin 
  }
  r = r + 1;
  v = v + 1;
  
  if ( voc_que.length < v+1){  
  document.location.href="test.html"; //une fois le jeu fini redirection vers une page de fin

}
} 

function reponse(){ // création d'un fonction pour afficher le nombre de réponse juste et fausse
  textSize(40);
  if ( rep_vrai <= 1) { // cela sert à avoir la bonne orthographe et fonction du nombre de réponse
        text('Réponse juste :'+ rep_vrai,width-(width-10),height-(height-75));
      } else {
        text('Réponses justes :'+rep_vrai, width-(width-10),height-(height-75));
      }
      if ( rep_faux <= 1) {
        text('Réponse fausse :'+ rep_faux, width-(width-10),height-(height-120));
      } else {
        text('Réponses fausses :'+rep_faux,width-(width-10),height-(height-120));
      }  
}
